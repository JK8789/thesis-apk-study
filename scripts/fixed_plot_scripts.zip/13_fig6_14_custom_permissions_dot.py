
import pandas as pd, numpy as np, matplotlib.pyplot as plt
from pathlib import Path
from matplotlib.patches import Patch
ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'Plots' / 'thesis_plot_scripts_projectpaths'; OUT.mkdir(parents=True, exist_ok=True)
df=pd.read_csv(ROOT/'dataset2/dataset2.csv')
appcol='apk_filename' if 'apk_filename' in df.columns else [c for c in df.columns if 'apk' in c.lower()][0]
wide=df.pivot_table(index=appcol,columns='store',values='custom_permissions_count',aggfunc='first').reset_index()
gp_col=[c for c in wide.columns if 'google' in c.lower() or 'play' in c.lower()][0]
rs_col=[c for c in wide.columns if 'rustore' in c.lower()][0]
wide['same']=wide[gp_col]==wide[rs_col]
wide=wide.sort_values([gp_col,rs_col], ascending=[True,True]).reset_index(drop=True)
x=np.arange(len(wide)); w=0.34
fig,ax=plt.subplots(figsize=(10.5,6.5))
for i,row in wide.iterrows():
    same=bool(row['same'])
    gp_color = '#000000' if same else '#F58518'
    rs_color = '#FFFFFF' if same else '#4C78A8'
    ax.bar(i-w/2, row[gp_col], width=w, color=gp_color, edgecolor='black', linewidth=0.8)
    ax.bar(i+w/2, row[rs_col], width=w, color=rs_color, edgecolor='black', linewidth=0.8)
ax.set_xticks(x); ax.set_xticklabels([str(v).replace('.apk','') for v in wide[appcol]], rotation=35, ha='right', fontsize=10)
ax.set_ylabel('Custom permissions count', fontsize=11); ax.set_xlabel('Applications', fontsize=11)
ax.set_title('Custom permissions by store', fontsize=14, pad=10)
legend = [
    Patch(facecolor='#F58518', edgecolor='black', label='Google Play (changed)'),
    Patch(facecolor='#4C78A8', edgecolor='black', label='RuStore (changed)'),
    Patch(facecolor='#000000', edgecolor='black', label='Google Play (unchanged)'),
    Patch(facecolor='#FFFFFF', edgecolor='black', label='RuStore (unchanged)'),
]
ax.legend(handles=legend, frameon=False, loc='upper right')
ax.grid(axis='y', linestyle=':', linewidth=0.8, alpha=0.18)
ax.spines['top'].set_visible(False); ax.spines['right'].set_visible(False)
fig.tight_layout(); out=OUT/'fig6_14_custom_permissions_dot.png'; fig.savefig(out,dpi=300,bbox_inches='tight'); print(out)
