
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT
OUT = ROOT / "Plots" / "thesis_plot_scripts_real"
OUT.mkdir(parents=True, exist_ok=True)

PAIR_ORDER = ['maps', 'taxi', 'rail1', 'rail2', 'ecom1', 'ecom2', 'ecom3', 'ecom4', 'bank1', 'bank2', 'bank3', 'bank4', 'health', 'social1', 'social2', 'msg1', 'msg2', 'gov1', 'gov2', 'gov3']
PAIR_LABELS = {
    'maps': 'Yandex Maps vs Google Maps',
    'taxi': 'Yandex Go Taxi vs Bolt',
    'rail1': 'RZD vs DB Navigator',
    'rail2': 'Yandex Trains vs Mobiliteit.lu',
    'ecom1': 'Ozon vs Amazon Shopping',
    'ecom2': 'Wildberries vs Zalando',
    'ecom3': 'Yandex Market vs bol',
    'ecom4': 'Avito vs Vinted',
    'bank1': 'Sberbank vs BGL',
    'bank2': 'Tinkoff vs ING Luxembourg',
    'bank3': 'Alfa Bank vs Revolut',
    'bank4': 'VTB vs BILnet',
    'health': 'EMIAS.INFO vs Doctena',
    'social1': 'VK vs Facebook',
    'social2': 'OK vs X',
    'msg1': 'MAX vs WhatsApp',
    'msg2': 'Yandex Telemost vs Telegram',
    'gov1': 'Gosuslugi vs MyGuichet.lu',
    'gov2': 'Nalogi FL vs impots.gouv',
    'gov3': 'Gosuslugi Biometria vs itsme',
}


def order_pairs(df, col="pair_id"):
    df = df.copy()
    df[col] = pd.Categorical(df[col], categories=PAIR_ORDER, ordered=True)
    return df.sort_values(col)

df = pd.read_csv(DATA / "results/native/native_summary.csv")
# expected columns: region, apps_total, apps_with_native, pct_with_native
if "pct_with_native" not in df.columns:
    if {"apps_total", "apps_with_native"}.issubset(df.columns):
        df["pct_with_native"] = 100 * df["apps_with_native"] / df["apps_total"]
fig, ax = plt.subplots(figsize=(7, 5))
colors = ["#00ACC1" if r=="ru" else "#FF7043" for r in df["region"].str.lower()]
ax.bar(df["region"].str.upper(), df["pct_with_native"], color=colors, width=0.55)
for _, r in df.iterrows():
    label = f'{int(r.get("apps_with_native", round(r["pct_with_native"]/5)) )}/{int(r.get("apps_total",20))} ({r["pct_with_native"]:.0f}%)'
    ax.text(r["region"].upper(), r["pct_with_native"] + 1, label, ha="center", fontsize=10)
ax.set_ylim(0, max(100, df["pct_with_native"].max()+10))
ax.set_ylabel("Apps with at least one native .so (%)")
ax.set_title("Prevalence of native libraries by region", fontsize=15, pad=12)
ax.grid(axis="y", linestyle=":", alpha=0.35)
fig.tight_layout()
fig.savefig(OUT / "fig6_8_native_so_prevalence_bar.png", dpi=300, bbox_inches="tight")
print(OUT / "fig6_8_native_so_prevalence_bar.png")
