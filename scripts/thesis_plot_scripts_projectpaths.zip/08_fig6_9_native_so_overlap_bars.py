
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT
OUT = ROOT / "Plots" / "thesis_plot_scripts_real"
OUT.mkdir(parents=True, exist_ok=True)

PAIR_ORDER = ['maps', 'taxi', 'rail1', 'rail2', 'ecom1', 'ecom2', 'ecom3', 'ecom4', 'bank1', 'bank2', 'bank3', 'bank4', 'health', 'social1', 'social2', 'msg1', 'msg2', 'gov1', 'gov2', 'gov3']
PAIR_LABELS = {
    'maps': 'Yandex Maps vs Google Maps',
    'taxi': 'Yandex Go Taxi vs Bolt',
    'rail1': 'RZD vs DB Navigator',
    'rail2': 'Yandex Trains vs Mobiliteit.lu',
    'ecom1': 'Ozon vs Amazon Shopping',
    'ecom2': 'Wildberries vs Zalando',
    'ecom3': 'Yandex Market vs bol',
    'ecom4': 'Avito vs Vinted',
    'bank1': 'Sberbank vs BGL',
    'bank2': 'Tinkoff vs ING Luxembourg',
    'bank3': 'Alfa Bank vs Revolut',
    'bank4': 'VTB vs BILnet',
    'health': 'EMIAS.INFO vs Doctena',
    'social1': 'VK vs Facebook',
    'social2': 'OK vs X',
    'msg1': 'MAX vs WhatsApp',
    'msg2': 'Yandex Telemost vs Telegram',
    'gov1': 'Gosuslugi vs MyGuichet.lu',
    'gov2': 'Nalogi FL vs impots.gouv',
    'gov3': 'Gosuslugi Biometria vs itsme',
}


def order_pairs(df, col="pair_id"):
    df = df.copy()
    df[col] = pd.Categorical(df[col], categories=PAIR_ORDER, ordered=True)
    return df.sort_values(col)

# Use unique native library names from native_libs_per_app.csv
df = pd.read_csv(DATA / "results/native/native_libs_per_app.csv")
name_col = "native_lib_name" if "native_lib_name" in df.columns else ("lib_name" if "lib_name" in df.columns else None)
if name_col is None:
    name_col = [c for c in df.columns if "name" in c.lower()][0]
sets = {r:set(g[name_col].dropna().astype(str).unique()) for r,g in df.groupby("region")}
ru = sets.get("ru", set()); eu = sets.get("eu", set())
vals = [len(ru - eu), len(ru & eu), len(eu - ru)]
labels = ["RU only", "Shared", "EU only"]
colors = ["#8E24AA", "#90A4AE", "#FDD835"]

fig, ax = plt.subplots(figsize=(7,5))
bars = ax.bar(labels, vals, color=colors, width=0.6)
for b, v in zip(bars, vals):
    ax.text(b.get_x() + b.get_width()/2, v + 0.3, str(v), ha="center", fontsize=11)
ax.set_ylabel("Unique native .so prefixes")
ax.set_title("Overlap of native library names across regions", fontsize=15, pad=12)
ax.grid(axis="y", linestyle=":", alpha=0.35)
fig.tight_layout()
fig.savefig(OUT / "fig6_9_native_so_overlap_bars.png", dpi=300, bbox_inches="tight")
print(OUT / "fig6_9_native_so_overlap_bars.png")
