
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT
OUT = ROOT / "Plots" / "thesis_plot_scripts_real"
OUT.mkdir(parents=True, exist_ok=True)

PAIR_ORDER = ['maps', 'taxi', 'rail1', 'rail2', 'ecom1', 'ecom2', 'ecom3', 'ecom4', 'bank1', 'bank2', 'bank3', 'bank4', 'health', 'social1', 'social2', 'msg1', 'msg2', 'gov1', 'gov2', 'gov3']
PAIR_LABELS = {
    'maps': 'Yandex Maps vs Google Maps',
    'taxi': 'Yandex Go Taxi vs Bolt',
    'rail1': 'RZD vs DB Navigator',
    'rail2': 'Yandex Trains vs Mobiliteit.lu',
    'ecom1': 'Ozon vs Amazon Shopping',
    'ecom2': 'Wildberries vs Zalando',
    'ecom3': 'Yandex Market vs bol',
    'ecom4': 'Avito vs Vinted',
    'bank1': 'Sberbank vs BGL',
    'bank2': 'Tinkoff vs ING Luxembourg',
    'bank3': 'Alfa Bank vs Revolut',
    'bank4': 'VTB vs BILnet',
    'health': 'EMIAS.INFO vs Doctena',
    'social1': 'VK vs Facebook',
    'social2': 'OK vs X',
    'msg1': 'MAX vs WhatsApp',
    'msg2': 'Yandex Telemost vs Telegram',
    'gov1': 'Gosuslugi vs MyGuichet.lu',
    'gov2': 'Nalogi FL vs impots.gouv',
    'gov3': 'Gosuslugi Biometria vs itsme',
}


def order_pairs(df, col="pair_id"):
    df = df.copy()
    df[col] = pd.Categorical(df[col], categories=PAIR_ORDER, ordered=True)
    return df.sort_values(col)

df = pd.read_csv(DATA / "results/datasafety/datasafety_long.csv")
# infer apps with neither collected nor shared
work = df.copy()
work["collected_item"] = work.get("collected_item", work.get("collected_data_item", work.get("data_item", "")))
work["shared_item"] = work.get("shared_item", work.get("shared_data_item", ""))
grp_cols = ["region", "pair_id", "app_name"] if "app_name" in work.columns else ["region", "pair_id"]
agg = work.groupby(grp_cols, as_index=False).agg(
    collected_any=("collected_item", lambda s: int(s.fillna("").astype(str).str.strip().replace("nan","").ne("").any())),
    shared_any=("shared_item", lambda s: int(s.fillna("").astype(str).str.strip().replace("nan","").ne("").any())),
)
agg["none_declared"] = ((agg["collected_any"] == 0) & (agg["shared_any"] == 0)).astype(int)
summ = agg.groupby("region", as_index=False).agg(apps=("none_declared","size"), none_apps=("none_declared","sum"))
summ["pct"] = 100*summ["none_apps"]/summ["apps"]

fig, ax = plt.subplots(figsize=(7,5))
colors = ["#7CB342" if r=="ru" else "#F4511E" for r in summ["region"]]
bars = ax.bar(summ["region"].str.upper(), summ["pct"], color=colors, width=0.55)
for b, (_, r) in zip(bars, summ.iterrows()):
    ax.text(b.get_x()+b.get_width()/2, b.get_height()+1, f'{int(r["none_apps"])}/{int(r["apps"])} ({r["pct"]:.0f}%)', ha="center", fontsize=10)
ax.set_ylabel("Apps (%)")
ax.set_ylim(0, max(100, summ["pct"].max()+15))
ax.set_title("Apps declaring no collected and no shared data", fontsize=15, pad=12)
ax.grid(axis="y", linestyle=":", alpha=0.35)
fig.tight_layout()
fig.savefig(OUT / "fig6_10_data_safety_none_bar.png", dpi=300, bbox_inches="tight")
print(OUT / "fig6_10_data_safety_none_bar.png")
