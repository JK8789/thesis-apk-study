
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT
OUT = ROOT / "Plots" / "thesis_plot_scripts_real"
OUT.mkdir(parents=True, exist_ok=True)

PAIR_ORDER = ['maps', 'taxi', 'rail1', 'rail2', 'ecom1', 'ecom2', 'ecom3', 'ecom4', 'bank1', 'bank2', 'bank3', 'bank4', 'health', 'social1', 'social2', 'msg1', 'msg2', 'gov1', 'gov2', 'gov3']
PAIR_LABELS = {
    'maps': 'Yandex Maps vs Google Maps',
    'taxi': 'Yandex Go Taxi vs Bolt',
    'rail1': 'RZD vs DB Navigator',
    'rail2': 'Yandex Trains vs Mobiliteit.lu',
    'ecom1': 'Ozon vs Amazon Shopping',
    'ecom2': 'Wildberries vs Zalando',
    'ecom3': 'Yandex Market vs bol',
    'ecom4': 'Avito vs Vinted',
    'bank1': 'Sberbank vs BGL',
    'bank2': 'Tinkoff vs ING Luxembourg',
    'bank3': 'Alfa Bank vs Revolut',
    'bank4': 'VTB vs BILnet',
    'health': 'EMIAS.INFO vs Doctena',
    'social1': 'VK vs Facebook',
    'social2': 'OK vs X',
    'msg1': 'MAX vs WhatsApp',
    'msg2': 'Yandex Telemost vs Telegram',
    'gov1': 'Gosuslugi vs MyGuichet.lu',
    'gov2': 'Nalogi FL vs impots.gouv',
    'gov3': 'Gosuslugi Biometria vs itsme',
}


def order_pairs(df, col="pair_id"):
    df = df.copy()
    df[col] = pd.Categorical(df[col], categories=PAIR_ORDER, ordered=True)
    return df.sort_values(col)

df = pd.read_csv(DATA / "results/datasafety/datasafety_long.csv")
# infer one collected item per row if available
if "collected_count" in df.columns:
    tmp = df.groupby(["pair_id","region"], as_index=False)["collected_count"].max()
else:
    item_col = "collected_item" if "collected_item" in df.columns else ("collected_data_item" if "collected_data_item" in df.columns else None)
    if item_col is None:
        raise ValueError("Need collected_count or collected_item column in datasafety_long.csv")
    tmp = df[df[item_col].fillna("").astype(str).str.strip() != ""].groupby(["pair_id","region"], as_index=False)[item_col].nunique().rename(columns={item_col:"collected_count"})
app = tmp.pivot(index="pair_id", columns="region", values=tmp.columns[-1]).fillna(0).reset_index()
app = order_pairs(app)
y = np.arange(len(app))
fig, ax = plt.subplots(figsize=(11,8))
for i, row in enumerate(app.itertuples(index=False)):
    ax.plot([row.ru, row.eu], [i, i], color="#ECEFF1", linewidth=2)
ax.scatter(app["ru"], y, s=80, color="#C62828", marker="^", label="RU")
ax.scatter(app["eu"], y, s=80, color="#2E7D32", marker="^", label="EU")
ax.set_yticks(y)
ax.set_yticklabels([PAIR_LABELS[p] for p in app["pair_id"]], fontsize=10)
ax.set_xlabel("Declared collected data items")
ax.set_title("Declared collected data items by matched pair", fontsize=16, pad=12)
ax.grid(axis="x", linestyle=":", alpha=0.35)
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig(OUT / "fig6_11_collected_data_dumbbell.png", dpi=300, bbox_inches="tight")
print(OUT / "fig6_11_collected_data_dumbbell.png")
